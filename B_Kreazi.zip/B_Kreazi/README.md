# b_kreazi

A new Flutter project.

## Prepare Project
- Nama package/ folder project : 
    > b_kreazi

- Replace beberapa file di folder "b_kreazi" dengan hasil extract dari "B_Kreazi.zip" (lib, assets, pubspec, plugins, ...)
- Buka terminal (powershell/ cmd)
- Eksekusi :
    > flutter pub get

- Buka file android/app/build.gradle
- Scroll ke bagian android {... defaultConfig ...}, edit "minSdkVersion flutter.minSdkVersion" menjadi :
    > minSdkVersion 19


## Prepare Application Icon
- Buka terminal (powershell/ cmd)
- Eksekusi :
    > flutter pub get

    > flutter pub run flutter_launcher_icons